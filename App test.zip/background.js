const ABOUT_BLANK_TIME_ALLOWED = 5000; // 5 seconds for about:blank
const NEW_TAB_TIME_ALLOWED = 30000; // 30 seconds for "New Tab"
const SCAN_INTERVAL = 2000; // Periodically scan every 2 seconds
const activeTimers = {};

console.log("Service worker initialized.");

// Function to remove a tab
function safelyRemoveTab(tabId) {
  chrome.tabs.remove(tabId, () => {
    if (chrome.runtime.lastError) {
      const errorMessage = chrome.runtime.lastError.message;
      console.error(`Failed to close tab ${tabId}: ${errorMessage}`);
    } else {
      console.log(`Tab ${tabId} successfully closed.`);
    }
  });
}

// Function to scan all tabs periodically
function scanAndCloseTabs() {
  chrome.tabs.query({}, (tabs) => {
    const currentTime = Date.now();

    tabs.forEach((tab) => {
      if (tab.url && (tab.url.includes("about:blank") || tab.title === "New Tab")) {
        // Initialize timer if not already set
        if (!activeTimers[tab.id]) {
          activeTimers[tab.id] = currentTime;
          console.log(`Started tracking tab ${tab.id} with title: "${tab.title}" and URL: ${tab.url}`);
        }

        // Determine timeout based on tab type
        const timeAllowed = tab.url.includes("about:blank") ? ABOUT_BLANK_TIME_ALLOWED : NEW_TAB_TIME_ALLOWED;

        // Check if the tab has exceeded the allowed time
        const elapsedTime = currentTime - activeTimers[tab.id];
        if (elapsedTime > timeAllowed) {
          console.log(`Closing tab ${tab.id} (elapsed time: ${elapsedTime} ms, type: "${tab.title}")`);
          safelyRemoveTab(tab.id);
          delete activeTimers[tab.id];
        }
      }
    });
  });
}

// Start periodic scanning
setInterval(scanAndCloseTabs, SCAN_INTERVAL);

// Cleanup timers when tabs are closed
chrome.tabs.onRemoved.addListener((tabId) => {
  if (activeTimers[tabId]) {
    delete activeTimers[tabId]; // Remove timer
    console.log(`Removed tracking for tab ${tabId}`);
  }
});
